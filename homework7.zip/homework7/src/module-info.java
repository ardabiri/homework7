/**
 * 
 */
/**
 * 
 */
module homework7 {
	requires java.sql;
}